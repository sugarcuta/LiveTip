import asyncio, json, io, webbrowser, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import time, re, base64, os, hashlib
from urllib.parse import urlsplit
LOCK=threading.RLock()

ROOT=Path(__file__).resolve().parent
def readstate(name,default):
    try: return json.loads((ROOT/name).read_text())
    except (OSError,ValueError): return default
def write(name,obj):
    tmp=ROOT/(name+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False));os.replace(tmp,ROOT/name)
def respond(h,obj):
    data=json.dumps(obj,ensure_ascii=False).encode();h.send_response(200);h.send_header('Content-Type','application/json; charset=utf-8');h.send_header('Cache-Control','no-store');h.end_headers();h.wfile.write(data)
def body(h,limit=15000000):
    n=int(h.headers.get('Content-Length',0))
    if not 0<n<=limit: raise ValueError('invalid length')
    return json.loads(h.rfile.read(n))
class Public(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path=='/config':
            with LOCK: respond(self,readstate('config.json',{}))
        elif self.path=='/':
            self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers();self.wfile.write((ROOT/'public.html').read_bytes())
        else: self.send_error(404)
    def do_POST(self):
        if self.path!='/donate': return self.send_error(404)
        try:
            d=body(self);a=d['amount'];name=str(d['name']).strip()[:40];msg=str(d.get('message',''))[:250];slip=d['slip'];assert type(a)==int and 10<=a<=100000 and name
            match=re.fullmatch(r'data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)',slip);assert match
            raw=base64.b64decode(match[2],validate=True);assert 0<len(raw)<=10485760
            assert raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8') or (raw.startswith(b'RIFF') and raw[8:12]==b'WEBP')
            digest=hashlib.sha256(raw).hexdigest()
            with LOCK:
                inbox=readstate('inbox.json',[]);seen=readstate('seen.json',[])
                if digest in seen or any(x.get('digest')==digest for x in inbox): return self.send_error(409,'Duplicate slip')
                if len(inbox)>=30: return self.send_error(503,'Inbox full')
                inbox.append(dict(id=time.time_ns()//1000,name=name,message=msg,amount=a,slip=slip,time=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),status='pending',digest=digest));write('inbox.json',inbox)
            respond(self,{'ok':True})
        except Exception: self.send_error(400,'Invalid donation')
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.headers.get('Host') not in ('127.0.0.1:8765','localhost:8765'): return self.send_error(403)
        if self.path in ('/studio.js','/overlay'):
            file='studio.js' if self.path=='/studio.js' else 'overlay.html';self.send_response(200);self.send_header('Content-Type','application/javascript' if file.endswith('.js') else 'text/html; charset=utf-8');self.end_headers();self.wfile.write((ROOT/file).read_bytes());return
        if self.path in ('/inbox','/events'):
            with LOCK: respond(self,readstate('inbox.json' if self.path=='/inbox' else 'events.json',[]))
            return
        if self.path.split('?')[0] not in ('/','/LiveTip.html'):
            self.send_error(404); return
        data=(ROOT/'LiveTip.html').read_bytes(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers(); self.wfile.write(data)
    def do_POST(self):
        if self.headers.get('Host') not in ('127.0.0.1:8765','localhost:8765'): return self.send_error(403)
        if self.path in ('/publish','/ack','/event'):
            if self.headers.get('Origin')!='http://127.0.0.1:8765': return self.send_error(403)
            try:
                d=body(self)
                with LOCK:
                    if self.path=='/publish':
                        assert re.fullmatch(r'[0-9]{13}',d['pp']);write('config.json',{k:d[k] for k in ('pp','profile','bio','avatar','banner') if k in d})
                    elif self.path=='/ack':
                        inbox=readstate('inbox.json',[]);ids=d['ids'];seen=readstate('seen.json',[]);seen.extend(x['digest'] for x in inbox if x['id'] in ids);write('seen.json',seen);write('inbox.json',[x for x in inbox if x['id'] not in ids])
                    else:
                        events=readstate('events.json',[]);events.append(dict(id=time.time_ns()//1000,name=str(d['name'])[:80],message=str(d['message'])[:400],amount=float(d['amount'])));write('events.json',events[-50:])
                respond(self,{'ok':True})
            except Exception: self.send_error(400,'Invalid data')
            return
        if self.path!='/tts'  or self.headers.get('Origin') not in ('http://127.0.0.1:8765', None):
            self.send_error(403); return
        try:
            n=int(self.headers.get('Content-Length',0)); assert 0<n<16000
            d=json.loads(self.rfile.read(n)); text=str(d['text']).strip()[:600]; assert text
            voice='th-TH-NiwatNeural' if d.get('gender')=='male' else 'th-TH-PremwadeeNeural'
            rate=f'{round((max(.6,min(1.5,float(d.get("rate",1))))-1)*100):+d}%'
            import edge_tts
            async def make():
                buf=io.BytesIO()
                async for chunk in edge_tts.Communicate(text,voice,rate=rate).stream():
                    if chunk['type']=='audio': buf.write(chunk['data'])
                return buf.getvalue()
            audio=asyncio.run(asyncio.wait_for(make(),25)); assert audio
            self.send_response(200); self.send_header('Content-Type','audio/mpeg'); self.send_header('Content-Length',str(len(audio))); self.end_headers(); self.wfile.write(audio)
        except Exception as e:
            self.send_error(502,'Online TTS unavailable: '+type(e).__name__)
if __name__=='__main__':
    public=ThreadingHTTPServer(('127.0.0.1',8766),Public)
    threading.Thread(target=public.serve_forever,daemon=True).start()
    server=ThreadingHTTPServer(('127.0.0.1',8765),Handler)
    threading.Timer(.8,lambda:webbrowser.open('http://127.0.0.1:8765')).start()
    print('LiveTip running: http://127.0.0.1:8765'); server.serve_forever()
