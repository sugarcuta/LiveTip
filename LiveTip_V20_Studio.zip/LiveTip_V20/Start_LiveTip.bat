@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (set "PY=python") else (set "PY=py -3")
%PY% --version || goto fail
%PY% -m pip install --upgrade edge-tts || goto fail
%PY% server.py
:fail
pause
